import boto3

s3_resource = boto3.resource('s3')
for key in spotify_keys:
    copy_source = {
        'Bucket': Bucket,
        'Key': key
        }
